package Edukids;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;

public class Edukids extends Frame implements ActionListener, Runnable {

	
	//creación de los objetos que tendra nuestro juego
	static JLabel lblPregunta, lblContador, lblModo, lblespacio1, lblespacio2, lblespacio3, lblespacio4, lblespacio5, lblespacio6, lblespacio7, lblespacio8, lblespacio9, lblespacio10, lblespacio11, lblespacio12, lblespacio13, lblespacio14, lblespacio15, lblespacio16, lblespacio17, lblespacio18, lblespacio19 ;
	static JButton btnRespuesta1, btnRespuesta2, btnRespuesta3, btnRespuesta4, btnAceptar, btnVolver;
	static String correcta;
	static JTextField txtResponder;
	static JPanel p1, p2, p3, p4, p5;
	static String opciones;
	
	//variables para las busquedas(temporales).
	static String categoria1;
	static String dificultad2;
	static String modo;
	
	//Variables para el tiemopo y conteo de preguntas
	static int sumar = 0; //reloj
	static int incorrecta =0; 
	static int acertada=0;	
	static int total;
	//static Thread contador;
	static boolean pararTiempo= false;
	
	//logo del programa
	String logo = "Logo";
	ImageIcon imgLogo, imgLibros, imgBalon, imgPlaneta, imgLeon, imgMate;
	static ImageIcon imgLogomd, imgLibrosmd, imgBalonmd, imgPlanetamd, imgLeonmd, imgMatemd;

	
	//Método constructor
	Edukids( String categoria, String dificultad){
	
		categoria1=categoria;
		dificultad2= dificultad;
		
		System.out.println(categoria1);
		//Configuración básica
		setTitle("Edukids");
		setSize(1350, 650);
		setLayout(new GridLayout (7, 3));
		
		
	//definir imagenes
		imgLogo = new ImageIcon (".\\src\\Edukids\\logooso.png");
		imgLibros = new ImageIcon (".\\src\\Edukids\\libros1.png");
		imgBalon = new ImageIcon (".\\src\\Edukids\\balonZapato.png");
		imgPlaneta = new ImageIcon (".\\src\\Edukids\\planeta1.png");
		imgLeon = new ImageIcon (".\\src\\Edukids\\leon1.png");
		imgMate = new ImageIcon (".\\src\\Edukids\\cajaMate.png");
		
		
		
		//Definir cada objero
		 lblPregunta = new JLabel();
		 btnRespuesta1 = new JButton();
		 btnRespuesta2 = new JButton();
		 btnRespuesta3 = new JButton();
		 btnRespuesta4 = new JButton();
		 btnVolver = new JButton("Regresar");
		 txtResponder = new JTextField("");
		 btnAceptar = new JButton("Verificar");
		 lblespacio1 = new JLabel();
		 lblespacio2 = new JLabel();
		 lblespacio3 = new JLabel();
		 lblespacio4 = new JLabel();
		 lblespacio5 = new JLabel();
		 lblespacio6 = new JLabel();
		 lblespacio7 = new JLabel();
		 lblespacio8 = new JLabel();
		 lblespacio9 = new JLabel();
		 lblespacio10 = new JLabel();
		 lblespacio11 = new JLabel();
		 lblespacio12 = new JLabel();
		 lblespacio13 = new JLabel();
		 lblespacio14 = new JLabel();
		 lblContador= new JLabel("Tiempo: " + sumar + " /30s");
		 lblespacio15 = new JLabel("             ");
		 lblespacio16 = new JLabel("                                                         ");
		 lblespacio17 = new JLabel("             ");
		 lblespacio18 = new JLabel("             ");
		 lblespacio19 = new JLabel("             ");
		 
		 lblespacio6.setBounds(300, 300, 100, 90);//tamaño del label
		 lblespacio14.setBounds(300, 300, 120, 110);
		 lblespacio12.setBounds(300, 300, 120, 90);  
		 lblespacio11.setBounds(300, 300, 110, 90); 
		 
		 imgLogomd = new ImageIcon(imgLogo.getImage().getScaledInstance(lblespacio6.getWidth(), lblespacio6.getHeight(), Image.SCALE_SMOOTH));//tamaño de la imagen	 
		 lblespacio2.setIcon(imgLogomd);
		 
		 imgLibrosmd = new ImageIcon(imgLibros.getImage().getScaledInstance(lblespacio6.getWidth(), lblespacio6.getHeight(), Image.SCALE_SMOOTH));
		 lblespacio6.setIcon(imgLibrosmd);
		 
		 imgBalonmd = new ImageIcon(imgBalon.getImage().getScaledInstance(lblespacio14.getWidth(), lblespacio14.getHeight(), Image.SCALE_SMOOTH));
		 lblespacio14.setIcon(imgBalonmd);
		 
		 imgPlanetamd = new ImageIcon(imgPlaneta.getImage().getScaledInstance(lblespacio6.getWidth(), lblespacio6.getHeight(), Image.SCALE_SMOOTH));
		 lblespacio9.setIcon(imgPlanetamd);
		 
		 imgLeonmd = new ImageIcon(imgLeon.getImage().getScaledInstance(lblespacio12.getWidth(), lblespacio12.getHeight(), Image.SCALE_SMOOTH));
		 lblespacio12.setIcon(imgLeonmd);
		 
		 imgMatemd = new ImageIcon(imgMate.getImage().getScaledInstance(lblespacio11.getWidth(), lblespacio11.getHeight(), Image.SCALE_SMOOTH));
		 lblespacio11.setIcon(imgMatemd);
		
		//PlaceHolder para el txtResponder
		 TextPrompt placeholder2 = new TextPrompt("Escribe la respuesta correcta aquí, según las opciones en pantalla", txtResponder);
		    placeholder2.changeAlpha(0.75f);
		    placeholder2.changeStyle(Font.ITALIC);
		 
		 
		//Dar diseño a los objetos
	 
		 lblPregunta.setFont( new Font ("Arial", Font.BOLD, 15));
		 lblPregunta.setOpaque(true);

		 
		 btnRespuesta1.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnRespuesta1.setBorder(BorderFactory.createLineBorder(new java.awt.Color(155, 255, 255)));
		 btnRespuesta1.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnRespuesta2.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnRespuesta2.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
		 btnRespuesta2.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnRespuesta3.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnRespuesta3.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
		 btnRespuesta3.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnRespuesta4.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnRespuesta4.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
		 btnRespuesta4.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnAceptar.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnAceptar.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
		 btnAceptar.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnVolver.setFont( new Font ("Arial", Font.PLAIN, 14));
		 btnVolver.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255)));
		 btnVolver.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		//dividir con un panel
    	p1= new JPanel();
     	p1.setLayout(new BorderLayout());
     	p1.add(lblespacio15, BorderLayout.CENTER);
    	p1.add(lblespacio2, BorderLayout.AFTER_LINE_ENDS);
    	
    	p2= new JPanel();
     	p2.setLayout(new BorderLayout());
     	p2.add(lblespacio6, BorderLayout.CENTER);
    	p2.add(lblespacio16, BorderLayout.LINE_START);
 
    	   	
    	p3= new JPanel();
     	p3.setLayout(new BorderLayout());
     	p3.add(lblespacio17, BorderLayout.CENTER);
    	p3.add(lblespacio14, BorderLayout.AFTER_LINE_ENDS);
    	
    	p4= new JPanel();
     	p4.setLayout(new BorderLayout());
     	p4.add(lblespacio18, BorderLayout.LINE_START);
    	p4.add(lblespacio9, BorderLayout.BEFORE_FIRST_LINE);
    	
    	p5= new JPanel();
     	p5.setLayout(new BorderLayout());
     	p5.add(lblespacio1, BorderLayout.CENTER);
    	p5.add(lblespacio12, BorderLayout.AFTER_LINE_ENDS);
    	

    	
    	//Añadir diseño a los objetos 
		 lblPregunta.setBackground(new java.awt.Color(28, 40, 51));
		 lblPregunta.setBorder(BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255 )));
		 lblPregunta.setForeground(new java.awt.Color(255, 255, 255 ));
		 
		 btnRespuesta1.setBackground(new java.awt.Color(28, 40, 51));
		 btnRespuesta2.setBackground(new java.awt.Color(28, 40, 51));
		 btnRespuesta3.setBackground(new java.awt.Color(28, 40, 51));
		 btnRespuesta4.setBackground(new java.awt.Color(28, 40, 51));
		 btnAceptar.setBackground(new java.awt.Color(28, 40, 51));
		 btnVolver.setBackground(new java.awt.Color(128, 139, 150));
		 lblContador.setFont( new Font ("Arial", Font.PLAIN, 22));
		 
		 
		 lblespacio1.setOpaque(true);
		 lblespacio2.setOpaque(true);
		 lblespacio3.setOpaque(true);
		 lblespacio4.setOpaque(true);
		 lblespacio5.setOpaque(true);
		 lblespacio6.setOpaque(true);
		 lblespacio7.setOpaque(true);
		 lblespacio8.setOpaque(true);
		 lblespacio9.setOpaque(true);
		 lblespacio10.setOpaque(true);
		 lblespacio11.setOpaque(true);
		 lblespacio12.setOpaque(true);
		 lblespacio13.setOpaque(true);
		 lblespacio14.setOpaque(true);
		 lblespacio15.setOpaque(true);
		 lblespacio16.setOpaque(true);
		 lblespacio17.setOpaque(true);
		 lblespacio18.setOpaque(true);
		 lblespacio19.setOpaque(true);
		 lblContador.setOpaque(true);
		 
		 lblespacio1.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio2.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio3.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio4.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio5.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio6.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio7.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio8.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio9.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio10.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio11.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio12.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio13.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio14.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio15.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio16.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio17.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio18.setBackground(new java.awt.Color(115, 198, 182));
		 lblespacio19.setBackground(new java.awt.Color(115, 198, 182));
		 lblContador.setBackground(new java.awt.Color(115, 198, 182));
		 lblContador.setForeground(new java.awt.Color(255, 255, 255));
		 
    	
		//Añadir los objetos  
		 add(lblContador);
		 add(lblPregunta);
		 add(lblespacio2);
		 add(lblespacio9);
		 add(lblespacio10);
		 add(p5);
		 add(btnRespuesta1);
		 add(lblespacio4);
		 add(btnRespuesta2);
		 add(lblespacio5);
		 add(p2);
		 add(lblespacio7);
		 add(btnRespuesta3);
		 add(lblespacio8);
		 add(btnRespuesta4);
		 add(lblespacio11);
		 add(lblespacio13);
		 add(p3);
		 add(txtResponder);
		 add(btnAceptar);
		 add(btnVolver);
		 
		//Hacer que nuestros objetos tengan funcionalidades 
		 btnRespuesta1.addActionListener(this);
		 btnRespuesta2.addActionListener(this);
		 btnRespuesta3.addActionListener(this);
		 btnRespuesta4.addActionListener(this);
		 btnAceptar.addActionListener(this);
		 btnVolver.addActionListener(this);
		
		
		 
		 // Agregar un adaptador de ventana para manejar el cierre de la ventana
	        addWindowListener((WindowListener) new WindowAdapter() {
	            public void windowClosing(WindowEvent e) {
	                // Cerrar la ventana cuando se hace clic en el botón de cerrar
	                System.exit(0);
	            }
	        });
		 
	        
	        
	}


	public static void cargarPregunta(String categoria, String dificultad) {
		categoria1=categoria;
		dificultad2= dificultad;
		
		
		//Busqueda de deporte
		if(categoria1=="Deportes" && dificultad2=="Fácil") {
				opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Deportes' AND dificultad='Fácil' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Deportes" && dificultad2=="Medio") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Deportes' AND dificultad='Medio' ORDER BY RAND() LIMIT 1";
		}
		
		if(categoria1=="Deportes" && dificultad2=="Difícil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Deportes' AND dificultad='Difícil' ORDER BY RAND() LIMIT 1";
		}
		
		//Busqueda para Historia
		if(categoria1=="Historia" && dificultad2=="Fácil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Historia' AND dificultad='Fácil' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Historia" && dificultad2=="Medio") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Historia' AND dificultad='Medio' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Historia" && dificultad2=="Difícil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Historia' AND dificultad='Difícil' ORDER BY RAND() LIMIT 1";
		}
	
		//Busqueda para Geografía
		if(categoria1=="Geografía" && dificultad2=="Fácil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Geografía' AND dificultad='Fácil' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Geografía" && dificultad2=="Medio") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Geografía' AND dificultad='Medio' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Geografía" && dificultad2=="Difícil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Geografía' AND dificultad='Difícil' ORDER BY RAND() LIMIT 1";
		}
		//Busqueda para Animales
		if(categoria1=="Animales" && dificultad2=="Fácil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Animales' AND dificultad='Fácil' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Animales" && dificultad2=="Medio") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Animales' AND dificultad='Medio' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Animales" && dificultad2=="Difícil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Animales' AND dificultad='Difícil' ORDER BY RAND() LIMIT 1";
		}
		
		//Busqueda para Matemáticas
		if(categoria1=="Matemáticas" && dificultad2=="Fácil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Matemáticas' AND dificultad='Fácil' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Matemáticas" && dificultad2=="Medio") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Matemáticas' AND dificultad='Medio' ORDER BY RAND() LIMIT 1";
		}
		if(categoria1=="Matemáticas" && dificultad2=="Difícil") {
			opciones = "SELECT * FROM preguntasJuego  WHERE categoria='Matemáticas' AND dificultad='Difícil' ORDER BY RAND() LIMIT 1";
		}
			
	    try {
	
	        // Conexión a la base de datos
	
	        Connection conn = DriverManager.getConnection("jdbc:mysql://hl1235.dinaserver.com/wp_71c08d5b93e506e8", "wp-71c08d5b93e50", "JPwq6O!^}826");
		

	        // Obtener una pregunta aleatoria
	        PreparedStatement stmt = conn.prepareStatement(opciones);
	
	        ResultSet rs = stmt.executeQuery();	
	
	
		        if (rs.next()) {
		        rs.getString(4);
		       String pregunta = rs.getString("pregunta");
		
		            String[] respuestas = {
		                rs.getString("respuestaCorrecta"),
		                rs.getString("respuesta2"),
		                rs.getString("respuesta3"),
		                rs.getString("respuesta4"),
		                
		            };
		
		            		
		            // Guardar la respuesta correcta (la primera)
		            correcta = respuestas[0];
		           
		            //Para saber si la pregunta es modelo escribir o seleccionar
		            modo=rs.getString(9);
		            System.out.println(modo);	       
		           // Mostrar la pregunta
		           
		            lblPregunta.setText(pregunta);
		
				
		            // Mezclar las respuestas de manera aleatoria
		            List<String> respuestasMezcladas = new ArrayList<>(List.of(respuestas));
		            Collections.shuffle(respuestasMezcladas);
		
		            
		            // Asignar las respuestas a los botones
		            btnRespuesta1.setText(respuestasMezcladas.get(0));
		            btnRespuesta2.setText(respuestasMezcladas.get(1));
		            btnRespuesta3.setText(respuestasMezcladas.get(2));
		            btnRespuesta4.setText(respuestasMezcladas.get(3));
				            		
		        }
	
	
	        rs.close();
	
	        stmt.close();
	
	        conn.close();
	               
	    } catch (Exception e) {
	
	        e.printStackTrace();
	        
	    }	  
	    
	    if(modo.equals("seleccionar")) {
	    	
	    	btnRespuesta1.setEnabled(true);
	    	btnRespuesta2.setEnabled(true);
	    	btnRespuesta3.setEnabled(true);
	    	btnRespuesta4.setEnabled(true);
	    	txtResponder.setEnabled(false);
	    	btnAceptar.setEnabled(false);
	    }
	    if(modo.equals("escrito")) {
	    	txtResponder.setEnabled(true);
	    	btnAceptar.setEnabled(true);
	    	btnRespuesta1.setEnabled(false);
	    	btnRespuesta2.setEnabled(false);
	    	btnRespuesta3.setEnabled(false);
	    	btnRespuesta4.setEnabled(false);
	    }
	    
	    

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//para botón 1
		if(e.getSource()== btnRespuesta1) {
		  if(btnRespuesta1.getText().equals(correcta)) {			 
			        sumar=0;		        
			//condición di hace click en la respuesta correcta	
			  mostrarDialogo("¡Respuesta correcta! ");
			  		sumar=0;
			  		acertada+=1;
			  		incorrecta-=1;
	      }else 	
	          mostrarDialogo("Respuesta incorrecta. ");
		  		    incorrecta++;
		  			sumar=0;
		}
		
		//para botón 2
		if(e.getSource()== btnRespuesta2) { 
		  if(btnRespuesta2.getText().equals(correcta)) {
			        sumar=0;
				//condición di hace click en la respuesta correcta	
				  mostrarDialogo("¡Respuesta correcta! ");				   
				  	sumar=0; 
				  	acertada+=1;
				  	incorrecta-=1;
		      }else 	
		          mostrarDialogo("Respuesta incorrecta. ");
		            incorrecta++;
		  			sumar=0;
		}

		//para botón 3
		if(e.getSource()== btnRespuesta3) {
				   sumar=0;
		  if(btnRespuesta3.getText().equals(correcta)) {
				//condición di hace click en la respuesta correcta	
				  mostrarDialogo("¡Respuesta correcta! ");			  
				   sumar=0;
				   acertada+=1;
				   incorrecta-=1;
		      }else 	
		          mostrarDialogo("Respuesta incorrecta. ");
		  	       incorrecta++;
		  		   sumar=0;
		}

		
		//Para botón 4
		if(e.getSource()== btnRespuesta4) {
				  sumar=0;
		  if(btnRespuesta4.getText().equals(correcta)) {
				//condición di hace click en la respuesta correcta	
				  mostrarDialogo("¡Respuesta correcta! ");				 
				  sumar=0;
				  acertada+=1;
				  incorrecta-=1;
		      }else 	
		          mostrarDialogo("Respuesta incorrecta. ");
		  		  incorrecta++;
		          sumar=0;
		}
		
		
		//Para botón verificar
		if(e.getSource()== btnAceptar) {
			    sumar=0;
		  if(txtResponder.getText().equals(correcta)) {
				//condición di hace click en la respuesta correcta	
			  mostrarDialogo("¡Respuesta correcta! ");			   
				txtResponder.setText("");
		        txtResponder.setFocusable(true);
		        sumar=0;
		        acertada+=1;
		        incorrecta-=1;
	      }else 	
	          mostrarDialogo("Respuesta incorrecta. ");
		        incorrecta++;
				txtResponder.setText("");
			    txtResponder.setFocusable(true);
			    sumar=0;
		}
	  
		if(e.getSource()== btnVolver) {
			total = acertada + incorrecta;
			mostrarDialogo("Preguntas totales hechas: " + total + " /acertadas: " + acertada + " /incorrectas: " + incorrecta);
			EdukidsCategDificultad ventana = new EdukidsCategDificultad(logo, logo); // Llamas a la clase Edukids con la variable "ventana"
			ventana.setVisible(true); // La ventana nueva (Edukids) se ve`
			sumar=0;
			acertada=0;
			incorrecta=0;
			EdukidsCategDificultad.contador.stop();
			setVisible(false);
		}     	     	  
	        
	   //llamar al método cargar pregunta para cambiar la pregunta.			
		cargarPregunta(categoria1, dificultad2);
		sumar=0;
		
	}

  

  private  void mostrarDialogo(String mensaje) {
      //método para mostrar mensajes en la pantalla  
      JOptionPane.showMessageDialog(this, mensaje);

  }

	public static void main(String[] args) {
		  //Crear una ventana para visuualizar
		
		Edukids ventana = new Edukids(categoria1, dificultad2);  
		
		try { //llamado a la base de datos

            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (ClassNotFoundException e) {

            e.printStackTrace();

        }
		
		    
		 //poner en visible la ventana creada.
		ventana.setVisible(true);
		 
		 //llamar al método para cargar las preguntas de la base de datos
	      cargarPregunta(categoria1, dificultad2);
	      ventana.setBackground(new java.awt.Color(153, 0, 255));
	      

		}



			@Override
			public void run() {
				while (!pararTiempo && sumar <30) {
		            try {
		                Thread.sleep(1000);
		            } catch (InterruptedException e) {
		                e.printStackTrace();
		            }
		            
	            	if(sumar>23) {
	            	lblContador.setForeground(new java.awt.Color(255, 0, 51));	
	            	}else  
		            lblContador.setForeground(new java.awt.Color(255, 255, 255));
	            
		            sumar++;
		            lblContador.setText(String.valueOf("Tiempo: " + sumar + " /30s"));
		        }
					//reinicio del contador
				if(sumar>29 && sumar<31) {
					mostrarDialogo("Tu tiempo se ha agotado");
					sumar=0;
					incorrecta++;
					lblContador.setForeground(new java.awt.Color(255, 255, 255));
			        lblContador.setText(String.valueOf("Tiempo: " + sumar + " /30s"));				
			        cargarPregunta(categoria1, dificultad2);
			        run();
				}
				
				
				
		    }
	   }
	
