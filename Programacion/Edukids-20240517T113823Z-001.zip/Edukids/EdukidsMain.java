package Edukids;

// Clase Main
public class EdukidsMain {
	public static void main(String[] args) {
		
		EdukidsLogin ventana = new EdukidsLogin();
		ventana.setVisible(true);

	}
}
