package Edukids;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.PasswordView;

public class EdukidsLogin extends Frame implements ActionListener, KeyListener {

	//Objetos de nuestra pantalla
	 JLabel lblNombre, lblContra, lblNombreDescrip, lblContraDescrip, lblInfo, lblInfo2, lblInfo3, lblInfo4;
	 static JTextField txtNombre;
	 static JPasswordField pswContra, pswVer;
	 JButton btnEnviar, btnSesion;
     JPanel p1, p2, p3;
     static char contraseña;
     
     //método para verificar login
     static String nombreVer;
     static String contraVer;
     static String nombre;
     static int si=0;
     static String pss;
     static String pas2;
    

    // Constructor
	EdukidsLogin(){
		
		//Cosas básicas de la pantalla
		setTitle("Edukids Login");
		setSize(400, 300);
		setLayout(new GridLayout (7, 1));		
		dispose() ;
		
		//Definir cada objeto
		lblNombre = new JLabel("Nombre");
		lblContra = new JLabel ("Contraseña");
		txtNombre = new JTextField ("");
		txtNombre.setFocusable(true);
		pswContra = new JPasswordField ("");
		btnEnviar = new JButton ("      Regístrate       ");
		btnSesion = new JButton ("    Inicia sesión     ");
		lblInfo = new JLabel("Inicia sesión o regístrate ");
		lblInfo2 = new JLabel("Completa todos los campos");
		lblInfo3 = new JLabel("La contraseña tiene que tener al menos 1 mayúscula");
		lblInfo4 = new JLabel("La contraseña tiene que tener mínimo 8 carácteres");
		
		//Diseño de los objetos		
		btnEnviar.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		btnEnviar.setBackground(new java.awt.Color(153, 0, 51));
		btnEnviar.setForeground(new java.awt.Color(255, 255, 255));
		
		btnSesion.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		btnSesion.setBackground(new java.awt.Color(153, 0, 51));
		btnSesion.setForeground(new java.awt.Color(255, 255, 255));
		
		 lblInfo.setFont( new Font ("Arial", Font.BOLD, 22));
		 lblInfo.setOpaque(true);
		 lblInfo.setBackground(new java.awt.Color(41, 182, 246));
		 lblInfo.setForeground(Color.white);
		 
		 lblInfo2.setFont( new Font ("Arial", Font.HANGING_BASELINE, 13));
		 lblInfo3.setFont( new Font ("Arial", Font.HANGING_BASELINE, 13));
		 lblInfo4.setFont( new Font ("Arial", Font.HANGING_BASELINE, 13));
		 
		 txtNombre.setBorder(BorderFactory.createLineBorder(new java.awt.Color(79, 195, 247)));
		 lblNombre.setForeground(new java.awt.Color(79, 195, 247));
	     lblNombre.setOpaque(true);
		 lblNombre.setBackground(new java.awt.Color(255, 255, 255));
		 
		 pswContra.setBorder(BorderFactory.createLineBorder(new java.awt.Color(79, 195, 247)));
		 lblContra.setForeground(new java.awt.Color(79, 195, 247));
	     lblContra.setOpaque(true);
		 lblContra.setBackground(new java.awt.Color(255, 255, 255));
		 	
		
		//poner un escrito
		TextPrompt placeholder = new TextPrompt("Escribe tu nombre aquí", txtNombre);
	    placeholder.changeAlpha(0.75f);
	    placeholder.changeStyle(Font.ITALIC);
	    
	    TextPrompt placeholder2 = new TextPrompt("Escribe tu contraseña aquí", pswContra);
	    placeholder2.changeAlpha(0.75f);
	    placeholder2.changeStyle(Font.ITALIC);
		
	    
		 
		//Paneles
		//panel 1
		p1= new JPanel();
     	p1.setLayout(new BorderLayout());
     	p1.add(txtNombre, BorderLayout.CENTER);
    	p1.add(lblNombre, BorderLayout.NORTH);
    	
    	//panel 2
    	p2= new JPanel();
     	p2.setLayout(new BorderLayout());
     	p2.add(pswContra, BorderLayout.CENTER);
    	p2.add(lblContra, BorderLayout.NORTH);
   
    	p3= new JPanel();
     	p3.setLayout(new BorderLayout());
     	p3.add(btnSesion, BorderLayout.WEST);
    	p3.add(btnEnviar, BorderLayout.LINE_END);
    	
    	//Añadir los objetos
    	add(lblInfo);
		add(p1);
		add(p2);
		add(p3); 
		add(lblInfo2);
		add(lblInfo3);
		add(lblInfo4);
    	
		//Hacer que nuestros objetos tengan funcionalidades 
		 btnEnviar.addActionListener(this);
		 btnSesion.addActionListener(this);
		 
		 //Meter lo del txt
		 pswContra.addKeyListener(this);
		 txtNombre.addKeyListener(this);
		 
		 
		 // Agregar un adaptador de ventana para manejar el cierre de la ventana
	        addWindowListener((WindowListener) new WindowAdapter() {
	            public void windowClosing(WindowEvent e) {
	                // Cerrar la ventana cuando se hace clic en el botón de cerrar
	                System.exit(0);
	            }
	        });
		 
		 
		 
	}
	
	
	private static void enviarDatos() {
	    try {
	        // Conexión a la base de datos
	        Connection conn = DriverManager.getConnection("jdbc:mysql://hl1235.dinaserver.com/wp_71c08d5b93e506e8", "wp-71c08d5b93e50", "JPwq6O!^}826");
	        
	        // Variables para los INSERT
	        String nombre = txtNombre.getText();
	        String contrasena = new String(pswContra.getPassword());
	        contrasena = encriptacion(contrasena);
	        
	        // Obtener una pregunta aleatoria	                                         	//Para que tome las variables puestas en los signos de interrogación
	        PreparedStatement stmt = conn.prepareStatement("INSERT INTO wp_users(user_login, user_pass) VALUES('" + nombre + "','" + contrasena + "')");
	        stmt.executeUpdate();
	
	        stmt.close();
	        conn.close();
	               
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }	  
	}	

	@Override
	public void actionPerformed(ActionEvent e) {		
		nombre = txtNombre.getText();
        String contrasena = new String(pswContra.getPassword());
		
        if(e.getSource()== btnSesion) {
        
	  if(!nombre.equals("") && !contrasena.equals("")) {
		if(contrasena.length()>7) {//cadena mayor que 7

			//función para verificar las mayúsculas
			 int contador = 0;
		     //Bucle para ver qué caracteres de cada palabra son mayúsculas
		     for (int i = 0; i < contrasena.length(); i++) {
		         char caracter = contrasena.charAt(i);
		         if (Character.isUpperCase(caracter)) {
		                contador++;
		         }
		     }
		     
		   if(contador!=0) {
			   verificarLogin();
			  if(si!=0) {
				  mostrarDialogo("Has iniciado sesión correctamente, puedes continuar");  
				  EdukidsCategDificultad ventana = new EdukidsCategDificultad(nombre, contrasena); // Llamas a la clase Edukids con la variable "ventana"
				  ventana.setVisible(true); // La ventana nueva (Edukids) se ve
				  setVisible(false); // Tu ventana no se ve
				  si=0;
			  }else {			   
				mostrarDialogo("Inicio de sesión fallido, intentalo otra vez");			
				txtNombre.setText("");
				pswContra.setText("");
				txtNombre.setFocusable(true);
				lblInfo3.setForeground(new java.awt.Color(255, 0, 51));
			    lblInfo2.setForeground(new java.awt.Color(255, 0, 51));
			    lblInfo4.setForeground(new java.awt.Color(255, 0, 51));
			  }
			  
			   	}else {
				   mostrarDialogo("La contrasena tiene que contener al menos 1 mayúscula"); 
			   	}
				
				}else {
					 mostrarDialogo("La contraseña debe tener mínimo 8 carácteres");
				}
				
		  		}else {
			  mostrarDialogo("El campo Nombre o Contraseña está vacío");
		  		}
        }
        
        
        if(e.getSource()== btnEnviar) {
        	if(!nombre.equals("") && !contrasena.equals("")) {
        		if(contrasena.length()>7) {//cadena mayor que 7

			//función para verificar las mayúsculas
			 int contador = 0;
		     //Bucle para ver qué caracteres de cada palabra son mayúsculas
		     for (int i = 0; i < contrasena.length(); i++) {
		         char caracter = contrasena.charAt(i);
		         if (Character.isUpperCase(caracter)) {
		                contador++;
		         }
		     }
		     
		   if(contador!=0) {
			   verificarLogin();
			  if(si!=0) {
				  mostrarDialogo("Este usuario ya está utilizado, prueba con otro o inicia sesión");  
				  si=0;
				  txtNombre.setText("");
				  pswContra.setText("");
				  txtNombre.setFocusable(true);
				  lblInfo3.setForeground(new java.awt.Color(255, 0, 51));
				  lblInfo2.setForeground(new java.awt.Color(255, 0, 51));
				  lblInfo4.setForeground(new java.awt.Color(255, 0, 51));
			  }else {			   
				enviarDatos();
				mostrarDialogo("Te has registrado correctamenet");			
				EdukidsCategDificultad ventana = new EdukidsCategDificultad(nombre, contrasena); // Llamas a la clase Edukids con la variable "ventana"
				ventana.setVisible(true); // La ventana nueva (Edukids) se ve
				setVisible(false); // Tu ventana no se ve
			  }
			  
			   	}else {
				   mostrarDialogo("La contraseña tiene que contener al menos 1 mayúscula"); 
			   	}
				
				}else {
					 mostrarDialogo("La contraseña debe tener mínimo 8 carácteres");
				}
				
		  		}else {
			  mostrarDialogo("El campo Nombre o Contraseña esta vacío");
		  		}	
        }
        
        
	} 
	
public static void main(String[] args) {
		
		EdukidsLogin ventana = new EdukidsLogin();
		ventana.setVisible(true);
		verificarLogin();
    		
	}
	
	 private  void mostrarDialogo(String mensaje) {
		 //Método para mostrar mensajes en la pantalla  
		 JOptionPane.showMessageDialog(this, mensaje);
	 }


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

       
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_ENTER) { //PARA UTILIZAR LAS TECLAS DEL TECLADO EN ESTE CASO ENTER			
			nombre = txtNombre.getText();
	        String contrasena = new String(pswContra.getPassword());
			
	        if(!nombre.equals("") && !contrasena.equals("")) {
	    		if(contrasena.length()>7) {//cadena mayor que 7

			//función para verificar las mayúsculas
			 int contador = 0;
		     //Bucle para ver qué caracteres de cada palabra son mayúsculas
		     for (int i = 0; i < contrasena.length(); i++) {
		         char caracter = contrasena.charAt(i);
		         if (Character.isUpperCase(caracter)) {
		                contador++;
		         }
		     }
		     
		   if(contador!=0) {
			   verificarLogin();
			  if(si!=0) {
				  mostrarDialogo("Has iniciado sesión correctamente, puedes continuar");  
				  EdukidsCategDificultad ventana = new EdukidsCategDificultad(nombre, contrasena); // Llamas a la clase Edukids con la variable "ventana"
				  ventana.setVisible(true); // La ventana nueva (Edukids) se ve
				  setVisible(false); // Tu ventana no se ve
				  si=0;
			  }else {			   
				mostrarDialogo("Inicio de sesión fallido, intentalo otra vez");			
				txtNombre.setText("");
				pswContra.setText("");
				txtNombre.setFocusable(true);
			  }
			  
			   	}else {
				   mostrarDialogo("La contrasena tiene que contener al menos 1 mayúscula"); 
			   	}
				
				}else {
					 mostrarDialogo("La contraseña debe tener mínimo 8 carácteres");
				}
				
		  		}else {
			  mostrarDialogo("El campo Nombre o Contraseña está vacío");
		  		}
		}
	}
	
	
	@Override
	public void keyReleased(KeyEvent e) {
	//variables de extracción de los datos
	 String contrasena = new String(pswContra.getPassword());
	 String nombre = txtNombre.getText();
	 
	//Condiciones para la longitud de la contraseña
			if(contrasena.length()>7) {
		       lblInfo4.setForeground(new java.awt.Color(76, 175, 80));
			}else {
			   lblInfo4.setForeground(new java.awt.Color(255, 0, 51));
			}
	  
	//Condiciones para la mayúscula
		int contador = 0;
	     //Bucle para ver qué caracteres de cada palabra son mayúsculas	 		 
	     for (int i = 0; i < contrasena.length(); i++) { 
	         char caracter = contrasena.charAt(i);
	         if (Character.isUpperCase(caracter)) {
	                contador++;
	         }
	     }		   
	        //Verificador del contador
		     if(contador!=0) {
				   lblInfo3.setForeground(new java.awt.Color(76, 175, 80));
				
				}else {
					lblInfo3.setForeground(new java.awt.Color(255, 0, 51));
				}
		     
		//Condiciones de campos
	     if(!nombre.equals("") && !contrasena.equals("")) {
	    	 lblInfo2.setForeground(new java.awt.Color(76, 175, 80)); 
	     }else {
	    	 lblInfo2.setForeground(new java.awt.Color(255, 0, 51));
	     }
	
	}
	
	
	
	public static void verificarLogin() {
		
		
		nombreVer = txtNombre.getText();
        contraVer =  new String(pswContra.getPassword());
  
		 try {
				
		        // Conexión a la base de datos
		
		        Connection conn = DriverManager.getConnection("jdbc:mysql://hl1235.dinaserver.com/wp_71c08d5b93e506e8", "wp-71c08d5b93e50", "JPwq6O!^}826");
		        contraVer = encriptacion(contraVer);
		        // Obtener una pregunta aleatoria
		        PreparedStatement stmt = conn.prepareStatement("SELECT user_login, user_pass FROM wp_users WHERE user_login='" + nombreVer + "' AND user_pass='" + contraVer + "' ");
		        
		        ResultSet rs = stmt.executeQuery();	
		     
			        if (rs.next()) {


			        if(rs.getString("user_login").equals(nombreVer) && rs.getString("user_pass").equals(contraVer)) {
			        	si++;
			        }
			        	
			  		            
			        }
		
		
		        rs.close();
		
		        stmt.close();
		
		        conn.close();
		               
		    } catch (Exception e) {
		
		        e.printStackTrace();
		        
		    }
		 
	
	}
	
	//Para encriptar algo
	public static String encriptacion(String contrasena) {

		String contrasenaEncriptada = "";

		try {

			/* Instancia MessageDigest para MD5 */

			MessageDigest m = MessageDigest.getInstance("MD5");



			/* Añadir bytes de texto de la contraseña para digerir con MD5. */

			m.update(contrasena.getBytes());



			/* Convertir el valor hash a bytes */

			byte[] bytes = m.digest();



			/*

			 * El array de bytes tiene bytes en forma decimal. Conversion a formato

			 * hexadecimal.

			 */

			StringBuilder s = new StringBuilder();

			for (int i = 0; i < bytes.length; i++) {

				s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));

			}



			/* Completar contraseña hash en formato hexadecimal */

			contrasenaEncriptada = s.toString();

		} catch (NoSuchAlgorithmException e) {

			e.printStackTrace();

		}

		return contrasenaEncriptada;

	}
	
	
	

}
