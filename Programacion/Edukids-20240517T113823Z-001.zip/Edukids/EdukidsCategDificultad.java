package Edukids;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class EdukidsCategDificultad extends Frame implements ActionListener, Runnable {

	//Qué bjetos hay
	static JLabel lblAviso, lblAviso2, lblespacio1, lblespacio2, lblespacio3, lblContador;
	static JRadioButton radCategoria1, radCategoria2, radCategoria3, radCategoria4, radCategoria5,radFacil, radDificil, radMedio;
	static JButton btnAceptar, btnVolver, btnRegistro;
	static String dificultad;
	static String categoria;
	static ButtonGroup btgCategoria, btgDificultad;
	
	//variables de tiempo
	static int sumar = 0; //reloj
	static int correctas =0; //preguntas correctas
	static int incorrectas=0;	//preguntas incorrectas
	static Thread contador;
	static boolean pararTiempo= false;
	static String nombres;
	static String modos;
	
	EdukidsCategDificultad (String nombre, String modo){ //Método constructor
		
		nombres=nombre;
		modos=modo;
		
		//Configuración básica
		setTitle("Edukids dificultad y categoría");
		setSize(400, 400);
		setLayout(new GridLayout (7, 2));
		
		//Definir cada objero
		 lblAviso = new JLabel("Elige la categoría");
		 lblAviso2 = new JLabel("Elige la dificultad");
		 lblespacio1 = new JLabel();
		 lblespacio2 = new JLabel();
		 lblespacio3 = new JLabel();
		 
		 //primer grupo
		 btgCategoria = new ButtonGroup();
		 radCategoria1 = new JRadioButton ("Historia");
		 radCategoria2 = new JRadioButton ("Animales");
		 radCategoria3 = new JRadioButton ("Matemáticas");
		 radCategoria4 = new JRadioButton ("Deporte"); 
		 radCategoria5 = new JRadioButton ("Geografía");		 
		 btgCategoria.add(radCategoria1); 
		 btgCategoria.add(radCategoria2);//Añadirlos al grupo
		 btgCategoria.add(radCategoria3);
		 btgCategoria.add(radCategoria4);
		 btgCategoria.add(radCategoria5);
		 
		//segundo grupo
		 btgDificultad = new ButtonGroup();
		 radFacil = new JRadioButton ("Fácil");
		 radMedio = new JRadioButton ("Medio");
		 radDificil = new JRadioButton ("Difícil");	
		 btgDificultad.add(radFacil);
		 btgDificultad.add(radMedio);
		 btgDificultad.add(radDificil);	
			 
		 
		 //botón de confirma
		 btnAceptar = new JButton("Aceptar");
		 btnRegistro = new JButton("Cerrar sesión");
		 
		 //Añadir los objetos a la pantalla
		 add(lblAviso);
		 add(lblAviso2);
		 add(radCategoria1);
		 add(radFacil);
		 add(radCategoria2);		 
		 add(lblespacio1);
		 add(radCategoria3);
		 add(radMedio);
		 add(radCategoria4);
		 add(lblespacio2);
		 add(radCategoria5);
		 add(radDificil);
		 add(btnAceptar);
		 add(btnRegistro);
		// add(lblespacio3);
		 
		 //Agregar Funcionalidad al botón
		 btnAceptar.addActionListener(this);
		 btnRegistro.addActionListener(this);
		 
		 //Agregar funcionalidades a las celeciones
		 radCategoria1.addActionListener(this);
		 radCategoria2.addActionListener(this);
		 radCategoria3.addActionListener(this);
		 radCategoria4.addActionListener(this);
		 radCategoria5.addActionListener(this);
		 
		 radFacil.addActionListener(this);
		 radDificil.addActionListener(this);
		 radMedio.addActionListener(this);
		 
		 
		 //Agregar diseño a los objetos
		 radCategoria1.setBackground(Color.WHITE);
		 radCategoria1.setForeground(new java.awt.Color(79, 195, 247));
		 radCategoria2.setBackground(Color.WHITE);
		 radCategoria2.setForeground(new java.awt.Color(79, 195, 247));
		 radCategoria3.setBackground(Color.WHITE);
		 radCategoria3.setForeground(new java.awt.Color(79, 195, 247));
		 radCategoria4.setBackground(Color.WHITE);
		 radCategoria4.setForeground(new java.awt.Color(79, 195, 247));
		 radCategoria5.setBackground(Color.WHITE);
		 radCategoria5.setForeground(new java.awt.Color(79, 195, 247));

		 
		 radFacil.setBackground(new java.awt.Color(255,255,255));
		 radFacil.setForeground(new java.awt.Color(79, 195, 247));
		 radMedio.setBackground(new java.awt.Color(255,255,255));
		 radMedio.setForeground(new java.awt.Color(79, 195, 247));
		 radDificil.setBackground(new java.awt.Color(255,255,255));
		 radDificil.setForeground(new java.awt.Color(79, 195, 247));
		 
		 lblespacio1.setOpaque(true);
		 lblespacio1.setBackground(new java.awt.Color(255,255,255));
		 lblespacio2.setOpaque(true);
		 lblespacio2.setBackground(new java.awt.Color(255,255,255));
		 lblespacio3.setOpaque(true);
		 lblespacio3.setBackground(new java.awt.Color(255,255,255));
		 
		 lblAviso.setOpaque(true);
		 lblAviso.setBackground(new java.awt.Color(41, 182, 246));
		 lblAviso.setFont( new Font ("Arial", Font.BOLD, 18));
		 lblAviso.setForeground(Color.white);
		 lblAviso2.setOpaque(true);
		 lblAviso2.setBackground(new java.awt.Color(41, 182, 246));
		 lblAviso2.setFont( new Font ("Arial", Font.BOLD, 18));
		 lblAviso2.setForeground(Color.white);
		 
		 btnAceptar.setBackground(new java.awt.Color(153, 0, 51));
		 btnAceptar.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		 btnAceptar.setForeground(Color.white);
		 
		 btnRegistro.setBackground(new java.awt.Color(153, 0, 51));
		 btnRegistro.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		 btnRegistro.setForeground(Color.white);
		 
		 
		 // Agregar un adaptador de ventana para manejar el cierre de la ventana
	        addWindowListener((WindowListener) new WindowAdapter() {
	            public void windowClosing(WindowEvent e) {
	                // Cerrar la ventana cuando se hace clic en el botón de cerrar
	                System.exit(0);
	            }
	        });	 
		 
	        
	   /*  if(modo!=null || nombres!=null) {
	    	 btnRegistro.setEnabled(false);
	     }*/
	        
	        
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
				
		//Botón para verificar
		if(e.getSource()== btnAceptar) {
			if (!btgCategoria.isSelected(null) && !btgDificultad.isSelected(null)) {
				Edukids ventana = new Edukids(dificultad, categoria ); // Llamas a la clase Edukids con la variable "ventana"
				ventana.setBackground(new java.awt.Color(0, 0, 0));
				contador = new Thread(ventana); 
			    contador.start();
				ventana.setVisible(true); // La ventana nueva (Edukids) se ve`
				setVisible(false);
				Edukids.cargarPregunta(categoria, dificultad);	
				
							
				 // Tu ventana no se ve
				
			}else {
				  mostrarDialogo("Aún no has seleccionado la Dificultad o la Categoría");
			}
		}
		
		
		//Poner las acciones de las selecciones
		//Categorias
		if(e.getSource()== radCategoria1) {
			categoria= "Historia";
		}
		
		if(e.getSource()== radCategoria2) {
			categoria= "Animales";
		}
		
		if(e.getSource()== radCategoria3) {
			categoria= "Matemáticas";
		}
		
		if(e.getSource()== radCategoria4) {
			categoria= "Deporte";
		}
		
		if(e.getSource()== radCategoria5) {
			categoria= "Geografía";
		}
		
		//Dificultades
		if(e.getSource()== radFacil) {
			dificultad= "Fácil";
		}
		
		if(e.getSource()== radMedio) {
			dificultad= "Medio";
		}
		
		if(e.getSource()== radDificil) {
			dificultad= "Difícil";
		}
		
		if(e.getSource()== btnRegistro) {
			mostrarDialogo("Pon tus datos para verificar si ya has iniciado sesión o no. Si has iniciado sesión en la página web de Edukids, ya estás registrado.");
			EdukidsLogin ventana = new EdukidsLogin();
			ventana.setVisible(true);			
			setVisible(false);
		}
		
		//System.out.println(categoria + " " +  dificultad );
				
	}
		
		
		private  void mostrarDialogo(String mensaje) {
			 //Método para mostrar mensajes en la pantalla  
			 JOptionPane.showMessageDialog(this, mensaje);
		 }

	public static void main(String[] args) {
		EdukidsCategDificultad ventana = new EdukidsCategDificultad(categoria, categoria);
		ventana.setVisible(true);
		
		
	}


	@Override
	public void run() {
		while (!pararTiempo && Integer.parseInt(lblContador.getText()) < 30) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            sumar = Integer.parseInt(lblContador.getText());
            sumar++;
            lblContador.setText(String.valueOf(sumar));
        }
      
        lblContador.setText("Tiempo: " + sumar + " /30s");
	}

}
